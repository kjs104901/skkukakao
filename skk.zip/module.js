// my modules
const meal = require("./node_my_modules/meal");
const library = require("./node_my_modules/library");
const weather = require("./node_my_modules/weather");
const notice = require("./node_my_modules/notice");
const transportation = require("./node_my_modules/transportation");
const calendar = require("./node_my_modules/calendar");

console.log(meal.getRestaurantList());